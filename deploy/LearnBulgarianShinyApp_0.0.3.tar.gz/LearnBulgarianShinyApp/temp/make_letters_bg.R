
library(tidyverse)


df <- read_csv("./data/bulgarian_letters_dataset.csv")
head(df)


c <- "Б" # 1041

# converts utf8 character to integer UTF-32 encoding
c_int <- utf8ToInt("Б")
c_int # 1041

# converts int or hex representation into Unicode text
c_uni <- Unicode::as.u_char(1041)
c_uni  # U+0411
print(c_uni)

# manually change and prints as correct character
print("\u0411")

# back to "Б" UTF-8 symbol 
intToUtf8(c_uni)

# same as int into hex and prepend "\U+"
c_hex <- as.hexmode(1041)  # 411
paste0("U+", str_pad(c_hex, width = 4, pad = "0"))


print(Unicode::as.u_char(1076))
print("\u0434")

# or use stringr functions:
stringr::str_conv("\u0411", "UTF8")
stringr::str_conv("Б", "UTF8")



convert_unicode_int_to_utf8 <- function(x, ...) {
  intToUtf8(as.hexmode(x), ...)
}

convert_unicode_int_to_utf8(1073)
convert_unicode_int_to_utf8(1074)
convert_unicode_int_to_utf8(1075)
convert_unicode_int_to_utf8(1073:1076, multiple = TRUE)



##################



df <- read_csv("./data/bulgarian_letters_dataset.csv")

questions <- paste0(
  "What is the transliteration for '",
  df$bg_upper, "/", df$bg_lower, "' ?"
  )

# all answers lowercase
answers <- df$transliteration_lower











