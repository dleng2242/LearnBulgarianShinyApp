# Deploying Containerized App to Azure Cloud
This file contains instructions on how to deploy the application image to the Azure Cloud so the app may be accessed via the web from any device. 

---
1. Open a terminal where the **Azure CLI is installed** and is capable of communicating with Docker (if you are using a Windows machine then **Command Prompt** or **PowerShell** work well) and **ensure your Docker daemon is running**.
---
2. Run the following commands in your terminal in turn.

A window will open in your default browser to authenticate your connection to Azure.
> `az login`

Create a resource group.
> `az group create --name {resource-group-name} -l {desired-server-location}`

Create an Azure Container Registry within the resource group, this is analogous to DockerHub and serves as a location to store images.
> `az acr create -n {container-registry-name} -g {resource-group-name} --sku {desired-price-plan}`

Authenticate to Azure Container Registry.
> `az acr login -n {container-registry-name}`

Create a local alias of the application image with the fully qualified path to your Azure Container Registry, this tells docker to use the azure container registry as the remote repository instead of DockerHub on push.
> `docker tag {local-image:version} {container-registry-name}.azurecr.io/{local-image:version}`

Push local alias to Azure Container Registry.
> `docker push {container-registry-name}.azurecr.io/{local-image:version}`

Create an App Service Plan within the resource group, this specifies the resources required to run your app and determines the price plan. If you deploy multiple apps, they can use the same price plan if desired.
> `az appservice plan create -g {resource-group-name} -n {appservice-plan-name} --sku {desired-price-plan} --is-linux`

Create a Webapp Service within the resource group, this specifies the assets which will form the app. In this case, a container is used, if you need to remember the path to your image this can be viewed in the Azure Container Registry through the portal or via the CLI.
> `az webapp create -g {resource-group-name} -p {appservice-plan-name} -n {webapp-name} -i {container-registry-name}.azurecr.io/{local-image:version}`
---
3. Open the Azure Portal and navigate to the Webapp Service created, there is a button labeled `Browse` which opens the webapp in a new tab, alternatively, the web address may be used. As Shiny apps typically consume several gigabytes of memory, this deployment method is prone to cold start delays, which may cause the web address to timeout at first. Allow at least 30 minutes for the systems to initialize after deployment. There should be no delays going forward.